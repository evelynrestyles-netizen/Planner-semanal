const addTaskBtn = document.getElementById("addTaskBtn");
const taskInput = document.getElementById("taskInput");
const daySelect = document.getElementById("daySelect");

let planner = JSON.parse(localStorage.getItem("planner")) || {};

addTaskBtn.addEventListener("click", () => {
  const task = taskInput.value.trim();
  const day = daySelect.value;

  if (!task) {
    alert("Digite uma tarefa antes de adicionar!");
    return;
  }

  if (!planner[day]) planner[day] = [];
  planner[day].push({ text: task, done: false });

  taskInput.value = "";
  savePlanner();
  renderTasks();
});

function renderTasks() {
  document.querySelectorAll(".day").forEach(dayDiv => {
    const day = dayDiv.dataset.day;
    const list = dayDiv.querySelector(".task-list");
    list.innerHTML = "";

    (planner[day] || []).forEach((task, index) => {
      const li = document.createElement("li");
      li.innerHTML = `
        <span style="text-decoration: ${task.done ? "line-through" : "none"}">${task.text}</span>
        <div>
          <button onclick="toggleTask('${day}', ${index})">✔</button>
          <button onclick="deleteTask('${day}', ${index})">🗑️</button>
        </div>
      `;
      list.appendChild(li);
    });
  });
}

function toggleTask(day, index) {
  planner[day][index].done = !planner[day][index].done;
  savePlanner();
  renderTasks();
}

function deleteTask(day, index) {
  planner[day].splice(index, 1);
  savePlanner();
  renderTasks();
}

function savePlanner() {
  localStorage.setItem("planner", JSON.stringify(planner));
}

renderTasks();